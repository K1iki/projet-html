Nom: François 
Prenom: Gerald Lovensky  
Niveau: 2eme Année Median
Vacation: Sces Info